var host = '192.168.7.8'; // SIP服务器地址，改成你自己的
var port = '35060';       // SIP端口，改成你自己的
// 将http和https分别替换为ws和wss
const protocol = window.location.protocol.replace('http', 'ws');
const wsUrl = protocol + "//" + host + ":" + port;

const SimpleUser = SIP.Web.SimpleUser;

const domain         = host;
const callerURI      = 'sip:alice@' + domain; // 主叫URI
const calleeURI      = 'sip:9196@' + domain;  // 被叫URI

// 获取HTML中的video标签，在呼叫时关联起来
const remoteVideoElement = document.getElementById("remoteVideo");
const localVideoElement  = document.getElementById("localVideo");

const configuration = {
	aor: callerURI,             // 主叫地址，Address of Record
	delegate: {                 // 回调函数
		onCallCreated: () => {  // 在呼叫创建时回调
		},
		onCallAnswered: () => { // 在应答时回调
			console.log('answered');
		},
		onCallHangup: () => {   // 在挂机时回调
		}
	},
	media: {                    // 媒体参数
		local: {                // 本地媒体关联HTML中的video标签
			video: localVideoElement,
		},
		remote: {               // 远端媒体关联HTML中的video标签
			audio: remoteVideoElement,
			video: remoteVideoElement,
		},
		constraints: {
			audio: true,        // 是否启用音频呼叫
			video: true,        // 是否启用视频呼叫
		}
	},
	userAgentOptions: {
		displayName: 'Alice',   // 显示名
		// authorizationUsername: 'alice',    // 鉴权用户名
		// authorizationPassword: 'password', // 密码
	},
};

// 创建一个简单的SIP UA，并连接
const simpleUser = new SimpleUser(wsUrl, configuration);
simpleUser.connect();
// simpleUser.register();  // 注册

function makeCall() { // 呼叫
	simpleUser.call(calleeURI);
}

function hangup() { // 挂断
	simpleUser.hangup();
}
