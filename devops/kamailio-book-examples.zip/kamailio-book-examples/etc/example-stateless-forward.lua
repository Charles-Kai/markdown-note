function ksr_register_ok()
	if KSR.is_method_in("R") then
		KSR.t_reply(200, "OK")
	end
end

function ksr_request_route()
	ksr_register_ok()
	-- KSR.forward("127.0.0.1:6666")
end
