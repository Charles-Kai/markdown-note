function ksr_request_route()
	ksr_register_always_ok()
	rc = KSR.speeddial.lookup("speed_dial")
	if rc == 1 then
		KSR.tm.t_relay()
		KSR.x.exit()
	else
		KSR.sl.sl_send_reply(404, "Not Found")
		KSR.x.exit()
	end
end
