function ksr_request_route()
	if KSR.siputils.has_totag() < 0 then
		if KSR.is_OPTIONS() then
			KSR.sl.sl_send_reply(200, "Keepalive")
			KSR.x.exit()
		else
			KSR.rr.record_route()
		end
	end

	if KSR.dispatcher.ds_is_from_list(100, 3) > 0 then
		ksr_route_from_fs()
	else
		ksr_route_to_fs()
	end
end

function ksr_route_from_fs()
	-- r-uri is user
	KSR.tm.t_relay()
	KSR.x.exit()
end

function ksr_route_to_fs()
	if KSR.siputils.has_totag() < 0 then
		-- if KSR.is_method_in("RISMP") then -- REGISTER, INVITE, SUBSCRIBER, MESSAGE, PUBLISH
		KSR.path.add_path_received()
		if KSR.dispatcher.ds_select_dst(100, 4) < 0 then
			KSR.sl.send_reply(404, "No destination")
		else
			KSR.tm.t_relay()
		end
		KSR.x.exit()
		-- end
	else
		-- Handle requests within SIP dialogs
		KSR.tm.t_relay()
		KSR.x.exit()
	end
end
