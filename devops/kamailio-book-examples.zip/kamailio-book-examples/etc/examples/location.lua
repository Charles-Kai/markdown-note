function ksr_request_route()
	if KSR.is_method_in("R") then
		KSR.registrar.save("location", 0);
		KSR.sl.sl_send_reply(200, "OK");
		KSR.x.exit()
	elseif KSR.is_method_in("I") then
		local rc = KSR.registrar.lookup("location");
		if rc < 0 then -- 如果找不到则根据返回值进行出错处理
			KSR.tm.t_newtran();
			KSR.sl.send_reply(404, "Not Found");
			KSR.x.exit();
		end
		KSR.tm.t_relay();
	end
end
