function ksr_request_route()
	KSR.rr.record_route()
	KSR.tm.t_relay()
end
