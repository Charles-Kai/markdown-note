function ksr_request_route()
    KSR.info("calling native routing block NATIVE\n")
	KSR.route("NATIVE")
	if KSR.pvx.var_get("exit") == 1 then
		KSR.x.exit()
	end
end
