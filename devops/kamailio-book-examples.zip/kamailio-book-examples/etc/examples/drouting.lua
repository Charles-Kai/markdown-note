function ksr_request_route()
	ksr_register_always_ok()
	KSR.info("Request URI = " .. KSR.pv.get("$ru") .. " before drouting\n")
	rc = KSR.drouting.do_routing("0")
	if rc == 1 then
		KSR.info("Destination URI = " .. KSR.pv.gete("$ru") .. " after drouting\n")
		KSR.tm.t_relay()
		KSR.x.exit()
	else
		KSR.sl.sl_send_reply(404, "Not Found")
		KSR.x.exit()
	end
end
