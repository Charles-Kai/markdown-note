function ksr_request_route()
	ksr_register_always_ok()
	local dest = KSR.pv.gete("$rU");
	if KSR.mtree.mt_match("pblock", dest, 0) == 1 then
		KSR.tm.t_send_reply("503", "Destination Blocked")
		KSR.x.exit()
	end
	KSR.tm.t_send_reply("404", "Not Found")
end
