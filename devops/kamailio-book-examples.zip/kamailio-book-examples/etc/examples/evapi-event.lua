function ksr_evapi_event(evname)
	if evname == "evapi:message-received" then
		local msg = KSR.pv.gete("$evapi(msg)")
		if msg:find("stats") == 1 then
			local request_body = '{"jsonrpc": "2.0", "method": "stats.fetch", "params": ["all"], "id": 1}'
			KSR.jsonrpcs.exec(request_body)
			local code = KSR.pv.gete("$jsonrpl(code)")
			local response_body = KSR.pv.gete("$jsonrpl(body)")
			KSR.evapi.relay(response_body)
		end
	end
end
