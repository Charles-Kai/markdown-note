function ksr_request_route()
    ksr_register_always_ok()

    local rU = KSR.pv.gete("$rU")
    matched = KSR.mtree.mt_match("mytree", rU, 0)
    KSR.info("rU = " .. rU .. " matched = " .. matched .. "\n")
    if matched == 1 then
        KSR.info("matched value: " .. KSR.pv.gete("$avp(s:tvalue)") .. "\n")
        KSR.forward_uri(KSR.pv.gete("$avp(s:tvalue)"))
        KSR.x.exit()
    else
        KSR.err("No match\n")
        KSR.sl.sl_send_reply(404, "Not Found")
    end
end
