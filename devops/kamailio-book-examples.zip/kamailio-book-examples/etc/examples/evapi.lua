-- apk add lua lua-cjson

local cjson = require 'cjson'

function ksr_request_route()
	ksr_register_always_ok()

	local rm = KSR.pv.gete("$rm")
	local fu = KSR.pv.gete("$fu")
	local ru = KSR.pv.gete("$ru")
	local si = KSR.pv.gete("$si")
	local dest = KSR.pv.gete("$rU")
	KSR.info("request: si: " .. si .. " rm: " .. rm .. " from " .. fu .. " to " .. ru .. " dest " .. dest .. "\n")

	if not KSR.is_method_in("I") then -- only handle INVITE
		return
	end

	KSR.tm.t_newtran()
	local tindex = KSR.pv.gete("$T(id_index)")
	local tlabel = KSR.pv.gete("$T(id_label)")
	KSR.info("transaction: index = " .. tindex .. " label = " .. tlabel .. "\n")

	local req = {
		jsonrpc = "2.0", method = "route",
		id = tindex .. ":" .. tlabel,
		params = {
			rm = rm, fu = fu, ru = ru, si = si, dest = dest
		}
	}
	local rpc = cjson.encode(req)
	KSR.info("rpc: " .. rpc .. "\n")

	local code = KSR.evapi.async_relay(rpc)
	if code == 1 then
		KSR.info("Transaction suspended\n")
	else
		KSR.err("Transaction suspend error, code = " .. code .. "\n")
	end
end

function ksr_evapi_event(evname)
	if evname == "evapi:message-received" then
		local msg = KSR.pv.gete("$evapi(msg)")
		KSR.info('EVAPI SERVER Received: ' .. msg .. "\n")
		local rpc = cjson.decode(msg)
		if rpc then
			if rpc.id and rpc.method == 'login' then -- a login request
				KSR.info("client login with user: " .. rpc.params.username .. " password: " .. rpc.params.password .. "\n")
				local res = {
					jsonrpc = "2.0",
					id = rpc.id,
					result = {
						code = 200,
						message = "login success",
					}
				}
				local response = cjson.encode(res)
				KSR.evapi.relay(response)
			elseif rpc.id and rpc.result then -- a response
				tindex, tlabel = rpc.id:match("(.+):(.+)")
				KSR.pv.sets('$var(evmsg)', msg)
				KSR.tmx.t_continue(tindex, tlabel, 'ksr_evapi_continue')
			end
		end
	end
end

function ksr_evapi_continue()
	local msg = KSR.pv.gete("$var(evmsg)")
	KSR.info("Transaction resumed, continue. msg: " .. msg .. "\n")
	local rpc = cjson.decode(msg)
	KSR.pv.sets("$du", rpc.result.route)
	KSR.tm.t_relay()
end
