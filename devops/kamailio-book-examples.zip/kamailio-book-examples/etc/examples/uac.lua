function ksr_request_route()
	ksr_register_always_ok()

	local rm = KSR.pv.gete("$rm")
	local fu = KSR.pv.gete("$fu")
	local ru = KSR.pv.gete("$ru")
	local si = KSR.pv.gete("$si")
	local dest = KSR.pv.gete("$rU")
	KSR.info("request: si: " .. si .. " rm: " .. rm .. " from " .. fu .. " to " .. ru .. " dest " .. dest .. "\n")

	if KSR.is_CANCEL() or (KSR.siputils.has_totag() > 0 and KSR.is_method_in("IBA")) then -- INVITE|BYE|ACK
		KSR.dialog.dlg_manage()
	end

	if KSR.siputils.has_totag()>0 then
		KSR.tm.t_relay()
		KSR.x.exit()
	end

	if KSR.is_INVITE() then	KSR.dialog.dlg_manage() end

	if KSR.uac.uac_reg_lookup(KSR.pv.gete("$rU"), "$ru") == 1 then -- from a provider
		KSR.info("request from a remote SIP provider [" .. KSR.pv.gete("$ou") .. " => " .. KSR.pv.gete("$ru") .. "]\n")
		KSR.registrar.lookup("location")
		KSR.rr.record_route()
		KSR.tm.t_relay()
	else -- maybe from local registered user
		local fU = KSR.pv.gete("$fU")
		local next_uri = ksr_get_next_uri(fU)
		if next_uri then
			KSR.info("next_uri: " .. next_uri .. "\n")
			KSR.pv.sets("$du", next_uri)
			KSR.rr.record_route();
			KSR.tm.t_on_failure("handle_trunk_auth")
			KSR.tm.t_relay()
		else
			KSR.sl.sl_send_reply(404, "Not Found")
			KSR.x.exit()
		end
	end
end

function ksr_get_next_uri(fu)
	-- be sure to escape fu before use in production
	local sql = "SELECT auth_proxy FROM uacreg WHERE l_uuid = '" .. fu .. "' LIMIT 1"
	local ret = KSR.sqlops.sql_xquery("example", sql, "reg_result")
	KSR.info('sql=' .. sql)
	if ret >= 0 then
		KSR.sqlops.sql_result_free("reg_result")
		if xdb_get_row("reg_result", 0) then
			local auth_proxy = xdb_gete_col("reg_result", 0, "auth_proxy")
			return auth_proxy
		end
	end
	return nil
end

function ksr_get_auth_data(l_uuid)
	-- be sure to escape fu before use in production
	local sql = "SELECT realm, auth_password FROM uacreg WHERE l_uuid = '" .. l_uuid .. "' LIMIT 1"
	local ret = KSR.sqlops.sql_xquery("example", sql, "reg_result")
	KSR.info('sql=' .. sql)
	if ret >= 0 then
		KSR.sqlops.sql_result_free("reg_result")
		if xdb_get_row("reg_result", 0) then
			local realm = xdb_gete_col("reg_result", 0, "realm")
			local auth_password = xdb_gete_col("reg_result", 0, "auth_password")
			return realm, auth_password
		end
	end
	return nil
end

function handle_trunk_auth()
    if KSR.tm.t_is_canceled()>0 then
		return 1
	end
	local status_code = KSR.tm.t_get_status_code()

	if status_code == 407 then -- need auth
		local auth_username = KSR.pv.gete("$fU")

		local realm, auth_password = ksr_get_auth_data(auth_username)
		KSR.pv.sets("$avp(arealm)", realm)
		KSR.pv.sets("$avp(auser)", auth_username)
		KSR.pv.sets("$avp(apasswd)", auth_password)

		if (KSR.uac.uac_auth() > 0) then
			if KSR.tm.t_relay() < 0 then
				KSR.sl.sl_reply_error()
			end
		else
			KSR.sl.sl_reply_error()
			KSR.x.exit()
		end
	end
end

function xdb_get_row(xavp, irow)
	return KSR.pv.get("$xavp(" .. xavp .. "[" .. tostring(irow) .. "])")
end

function xdb_gete_col(xavp, irow, col_name)
	return KSR.pv.gete("$xavp(" .. xavp .. "[" .. tostring(irow) .. "]=>" .. col_name ..")")
end
