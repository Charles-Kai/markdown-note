function ksr_request_route()
	ksr_register_always_ok()
	local rm = KSR.pv.gete("$rm")
	local fu = KSR.pv.gete("$fu")
	local ru = KSR.pv.gete("$ru")
	local si = KSR.pv.gete("$si")
	KSR.info("request: si: " .. si .. " rm: " .. rm .. " from " .. fu .. " to " .. ru .. "\n")

	rc = KSR.dialplan.dp_replace(2, KSR.pv.gete("$rU"), "$var(new_rU)")
	if rc == 1 then
		KSR.info("dp_attrs = " .. KSR.pv.gete("$avp(dp_attrs)") .. "\n")
		KSR.pv.sets("$rU", KSR.pv.get("$var(new_rU)"))
		KSR.pv.sets("$tU", KSR.pv.get("$var(new_rU)"))
		KSR.pv.sets("$tn", KSR.pv.get("$var(new_rU)"))
		KSR.pv.sets("$du", FS1_URI)
		KSR.tm.t_relay()
	else
		KSR.sl.sl_send_reply(404, "Not Found")
		KSR.x.exit()
	end
end
