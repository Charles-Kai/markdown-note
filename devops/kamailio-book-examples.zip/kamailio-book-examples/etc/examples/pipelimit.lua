function ksr_request_route()
	ksr_register_always_ok()
	if KSR.pipelimit.pl_check("test") < 0 then
		KSR.pipelimit.pl_drop();
		KSR.x.exit();
	end
	KSR.info("Good to go\n")
end
