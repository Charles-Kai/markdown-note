FLT_ACC=1           -- 记账相关的标志，要跟`kamailio.cfg`中一致
FLT_ACCMISSED=2
FLT_ACCFAILED=3

function ksr_request_route()
	ksr_register_always_ok()

	if KSR.is_INVITE() or KSR.is_BYE() then -- 简单起见，呼叫开始和结束都记
		KSR.setflag(FLT_ACC)       -- 设置事务标志，表示要记账（跟acc模块的log_flag参数对应起来）
		KSR.setflag(FLT_ACCFAILED) -- 如果呼叫失败，那么同时保存到acc表和missed_calls表
	end

	KSR.rr.record_route();
	KSR.pv.sets("$du", FS1_URI)
	KSR.tm.t_relay()
end
