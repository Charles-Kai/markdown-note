function ksr_request_route()
	ksr_register_always_ok()
	local rU = KSR.pv.gete("$rU")
	if KSR.lcr.load_gws(1, rU) == 1 then
		if KSR.lcr.next_gw() == 1 then
			KSR.info("ruleid = " .. KSR.pv.gete("$avp(lcr_ruleid)") .. "\n")
			KSR.info("$du = " .. KSR.pv.gete("$du")  .. "\n")
			KSR.info("$ru = " .. KSR.pv.gete("$ru")  .. "\n")
			KSR.tm.t_relay()
			KSR.x.exit()
		end
	end
	KSR.sl.send_reply(503, "No available gateways")
end
