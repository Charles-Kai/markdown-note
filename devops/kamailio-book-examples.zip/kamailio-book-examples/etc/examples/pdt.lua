function ksr_request_route()
	ksr_register_always_ok()
	if KSR.pdt.pd_translate(KSR.pv.get("$fd"),  0) == 1 then
		KSR.info("new ru: " .. KSR.pv.get("$ru") .. "\n")
		KSR.tm.t_relay()
	else
		KSR.sl.sl_send_reply(404, "Not Found")
		KSR.x.exit()
	end
end
