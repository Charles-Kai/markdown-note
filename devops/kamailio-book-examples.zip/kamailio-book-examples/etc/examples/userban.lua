function ksr_request_route()
    local au
	local auth_count
	au = KSR.pv.get("$au")
	if au then
		auth_count = KSR.htable.sht_get("userban", au .. "::auth_count")
		if auth_count and auth_count >= 1 then
			local exp = KSR.pv.get("$Ts") - 900
			if KSR.htable.sht_get("userban", au .. "::last_auth") > exp then
				KSR.err("auth - User blocked\n")
				KSR.sl.sl_send_reply(403, "Try later")
				KSR.x.exit()
			else
				KSR.htable.sht_seti("userban", au .. "::auth_count" , 0)
			end
		end
	end

	if KSR.hdr.is_present("Authorization") < 0 and KSR.hdr.is_present("Proxy-Authorization") < 0 then
		KSR.auth.auth_challenge(KSR.kx.gete_fhost(), 0)
		KSR.x.exit()
	end

	-- authenticate requests
	if KSR.auth_db.auth_check(KSR.kx.gete_fhost(), "subscriber", 1) < 0 then
		if not auth_count then
			KSR.htable.sht_seti("userban", au .. "::auth_count" , 0)
		end
		auth_count = KSR.htable.sht_inc("userban", au .. "::auth_count")
		KSR.info("auth_count = " .. auth_count .. "\n")
		if auth_count >= 10 then
			KSR.err("many failed auth in a row\n")
		end
		KSR.htable.sht_seti("userban", au .. "::last_auth", KSR.pv.get("$Ts"))
		KSR.auth.auth_challenge(KSR.kx.gete_fhost(), 0)
		KSR.x.exit()
	end
	KSR.htable.sht_rm("userban", au .. "::auth_count")
	-- user authenticated - remove auth header
	if not KSR.is_method_in("RP") then
		KSR.auth.consume_credentials()
	end
    -- go ahead
	return 1
end
