function ksr_request_route()
	ksr_register_always_ok()
	KSR.pv.sets("$du", FS1_URI)
	KSR.forward()
end
