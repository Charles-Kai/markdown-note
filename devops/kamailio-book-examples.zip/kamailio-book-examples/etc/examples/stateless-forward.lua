function ksr_request_route()
	ksr_register_always_ok()
	-- KSR.forward_uri("sip:172.18.0.3:5080")
	KSR.forward_uri(FS1_URI)
end
