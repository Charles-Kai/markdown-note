function ksr_request_route()
    KSR.x.drop();
end

function ksr_reply_route()
    KSR.x.drop();
end
