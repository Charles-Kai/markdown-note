-- apk add lua lua-cjson

local cjson = require 'cjson'

function ksr_request_route()
	ksr_register_always_ok()

	if KSR.is_INVITE() then
		if KSR.tm.t_is_set("failure_route") < 0 then
			KSR.tm.t_on_failure("ksr_failure_manage");
		end
	end

	local rm = KSR.pv.gete("$rm")
	local fu = KSR.pv.gete("$fu")
	local ru = KSR.pv.gete("$ru")
	local si = KSR.pv.gete("$si")
	KSR.info("request: si: " .. si .. " rm: " .. rm .. " from " .. fu .. " to " .. ru .. "\n")

	local url = "http://" .. KSR.kx.get_def("KAM_IP_LOCAL") .. ":" .. KSR.kx.get_def("KAM_SIP_PORT")
	local req = {
		rm = rm,
		fu = fu,
		ru = ru,
		si = si,
	}
	local post_body = cjson.encode(req)
	local code = KSR.http_client.query_post_hdrs(url, post_body, "Content-Type: application/json\r\nAuthorization: Bearer 1234", "$var(result)")

	KSR.info("code: " .. code .. "\n")
	KSR.info("result: " .. KSR.pvx.var_get("result") .. "\n")

	if code == 200 then
		KSR.rtjson.init_routes(KSR.pvx.var_get("result"));
		KSR.rtjson.push_routes();
		KSR.tm.t_relay()
	else
		KSR.sl.sl_send_reply(500, "Internal Error")
	end
end

function ksr_failure_manage()
	if KSR.tm.t_is_canceled()>0 then
		return 1
	end

	local status_code = KSR.tm.t_get_status_code()
	KSR.warn("call failed with status=" .. status_code .. " retrying ...\n")

	if KSR.rtjson.next_route() then
		KSR.tm.t_relay()
	else
		KSR.tm.t_send_reply(500, "No more routes available")
	end
end

function ksr_xhttp_event(evname)
	KSR.info("==== http request:" ..  evname .. " " .. "Ri:" ..  KSR.pv.get("$Ri") .. "\n")

	if KSR.hdr.get("Authorization") ~= "Bearer 1234" then
		KSR.hdr.append_to_reply('WWW-Authenticate: Bearer error="invalid_token"\r\n')
		KSR.xhttp.xhttp_reply("401", "Unauthorized", "", '{"code": 401, "message": "invalid_token"}')
		return
	end

	local content_type = KSR.pv.get("$cT") or ""
	local req_body = KSR.pv.get("$rb")

	if not req_body or content_type ~= "application/json" then
		KSR.xhttp.xhttp_reply(400, "Client Error", "text/plain", "invalid content_type or body")
		return
	end

	-- local jbody = cjson.decode(req_body)
	KSR.notice("request body: " .. req_body .. "\n")

	local reply = {
		version = "1.0",
		routing = "serial",
		routes = {{
			dst_uri = FS1_URI,
			headers = {
				from = {
					display = "Caller",
					uri = "sip:caller@domain.com",
				},
				to = {
					display = "Callee",
					uri = "sip:callee@domain.com"
				},
			},
			branch_flags = 8,
			fr_timer = 5000,
			fr_inv_timer = 30000,
		}, {
			dst_uri = FS1_URI,
			headers = {
				from = {
					display = "Caller",
					uri = "sip:caller@domain.com",
				},
				to = {
					display = "Callee",
					uri = "sip:callee@domain.com"
				},
			},
			branch_flags = 8,
			fr_timer = 5000,
			fr_inv_timer = 30000,
		}}
	}
	local body = cjson.encode(reply)
	KSR.xhttp.xhttp_reply(200, "OK", "application/json", body)
	return 1
end
