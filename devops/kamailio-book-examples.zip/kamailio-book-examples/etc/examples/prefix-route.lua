function ksr_request_route()
	ksr_register_always_ok()
	KSR.prefix_route.prefix_route_uri()
end

function ksr_prefix_route(prefix)
	KSR.info("prefix = " .. prefix .. "\n")
	local to = KSR.pv.get("$tU")
	if prefix == "BJ" then
		KSR.pv.sets("$du", FS1_URI)
	elseif prefix == "GZ" then
		KSR.pv.sets("$du", "192.168.1.101:5060")
	elseif prefix == "SH" then
		KSR.pv.sets("$du", "192.168.1.102:5060")
	elseif prefix == "YT" then
		KSR.pv.sets("$du", "192.168.1.103:5060")
	else
		KSR.sl.sl_send_reply(404, "Not Found")
		return
	end
	KSR.rr.record_route();
	KSR.tm.t_relay()
end
