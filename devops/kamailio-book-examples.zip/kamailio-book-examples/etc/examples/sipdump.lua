function ksr_sipdump_event(evname)
    KSR.info("from: " .. KSR.sipdump.get_src_ip() .. " to: " .. KSR.sipdump.get_dst_ip() .. " tag: " .. KSR.sipdump.get_tag() .. "\n" .. KSR.sipdump.get_buf());
end
