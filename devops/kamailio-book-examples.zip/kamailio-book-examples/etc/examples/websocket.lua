function ksr_request_route()
	ksr_register_always_ok()

	KSR.rr.record_route();
	KSR.pv.sets("$du", FS1_URI .. ';transport=tcp')
	KSR.tm.t_relay()
	KSR.x.exit()
end

function ksr_xhttp_event(evname)
	KSR.set_reply_close()
	KSR.set_reply_no_connect()

	KSR.info("==== http request:" ..  evname .. " " .. "Ri:" ..  KSR.pv.get("$Ri") .. "\n")
	local upgrade = KSR.hdr.get("Upgrade")
	if upgrade == "websocket" then
		if KSR.websocket.handle_handshake() > 0 then
			-- good
			KSR.info("handshake ok\n")
		else
			KSR.err("Handshake ERR\n")
		end
		return 1
	end

	KSR.xhttp.xhttp_reply(404, "Not Found", "text/plain", "Not Found")
	return 1
end
