function ksr_request_route()
	ksr_register_always_ok()

	KSR.rr.record_route();
	KSR.pv.sets("$du", FS1_URI)
	KSR.tm.t_relay()
	-- KSR.tm.t_relay_to_proxy(FS1_UDP)
	-- KSR.tm.t_relay_to_proxy_flags(FS1_UDP, 0)
end
