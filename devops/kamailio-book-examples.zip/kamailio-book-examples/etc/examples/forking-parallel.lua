function ksr_request_route()
	ksr_register_always_ok()
	KSR.corex.append_branch_uri('sip:10000486@' .. FS1_IP_PORT)
	KSR.corex.append_branch_uri('sip:10000200@' .. FS1_IP_PORT)
	KSR.pv.sets("$du", FS1_URI)
	KSR.tm.t_relay()
end
