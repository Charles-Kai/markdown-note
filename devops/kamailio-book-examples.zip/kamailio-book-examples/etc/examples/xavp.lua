function ksr_request_route()
	if KSR.registrar.save("location", 0)<0 then
		KSR.sl.sl_reply_error()
		KSR.x.exit()
	end
	KSR.pvx.pv_xavp_print()
	KSR.info("ruid = " .. KSR.pv.gete("$xavp(ulrcd[0]=>ruid)") .. "\n")
	KSR.info("contact = " .. KSR.pv.gete("$xavp(ulrcd[0]=>contact)") .. "\n")
	KSR.info("received = " .. KSR.pv.gete("$xavp(ulrcd[0]=>received)") .. "\n")
	KSR.info("expires = " .. KSR.pv.getvn("$xavp(ulrcd[0]=>expires)", 0) .. "\n")
end
