function ksr_request_route()
	ksr_register_always_ok()

	if KSR.is_INVITE() then
		KSR.rr.record_route();

		if KSR.tm.t_is_set("failure_route") < 0 then
			KSR.tm.t_on_failure("ksr_failure_manage");
		end
	end

	KSR.pv.sets("$du", FS1_URI)
	KSR.tm.t_relay()
end

function ksr_failure_manage()
	if KSR.tm.t_is_canceled()>0 then
		return 1
	end

	local status_code = KSR.tm.t_get_status_code()
	KSR.warn("call failed with status=" .. status_code .. " retrying ...\n")

	-- KSR.cfgutils.sleep(8)
	KSR.pv.sets("$tU", '9196')
	KSR.pv.sets("$rU", '9196')
	KSR.pv.sets("$du", FS1_URI)
	KSR.tm.t_relay()
end
