function ksr_request_route()
    ksr_register_always_ok()

    if KSR.is_INVITE() then
        KSR.rr.record_route();
        if KSR.tm.t_is_set("failure_route") < 0 then
            KSR.tm.t_on_failure("ksr_failure_manage");
        end
    end

    if KSR.dispatcher.ds_select_dst(100, 4) < 0 then
        KSR.sl.send_reply(404, "No destination")
        KSR.x.exit()
    else
        KSR.tm.t_relay()
    end
end

function ksr_failure_manage()
    if KSR.tm.t_is_canceled() > 0 then return 1 end

    local status_code = KSR.tm.t_get_status_code()
    KSR.warn("call failed with status=" .. status_code .. " retrying ...\n")

    if KSR.tm.t_check_status("[4-5][0-9][0-9]") or
        (KSR.tm.t_branch_timeout() > 0 and KSR.tm.t_branch_replied() < 0) then

        local ret = KSR.dispatcher.ds_next_dst()
        if ret > 0 then
            dst = KSR.pv.gete('$xavp(_dsdst_[0]=>uri)')
            KSR.notice("dispatch FAILED, trying next " .. dst)
            KSR.info("--- SCRIPT: going to <" .. KSR.pv.get("$ru") .. "> via <" ..
                     KSR.pv.get("$du") .. ">")
            ksr_route_relay()
        else
            KSR.notice("dispatch FAILED, no more dst to try")
        end
    end
    KSR.x.exit()
end
