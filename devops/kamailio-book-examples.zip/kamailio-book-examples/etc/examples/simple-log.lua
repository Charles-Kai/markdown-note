function ksr_request_route()
    KSR.info("Got a SIP Message, method=" .. KSR.pv.gete('$rm') ..
        " from IP: " .. KSR.pv.gete("$si") .. "\n")
    KSR.sl.send_reply("200", "OK")
end
