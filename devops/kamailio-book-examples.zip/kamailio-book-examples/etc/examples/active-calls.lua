FLT_ACALLS = 10

function ksr_request_route()
	ksr_register_always_ok()
	KSR.pv.seti("$xavp(caller=>active_calls)", 1) -- 设置最大并发呼叫数
	ksr_route_dialog()
	KSR.rr.record_route();
	KSR.pv.sets("$du", FS1_URI)
	KSR.tm.t_relay()
end

function ksr_route_dialog()
	if KSR.is_CANCEL() or
		(KSR.siputils.has_totag() > 0 and KSR.is_method_in("IBA")) then -- INVITE|BYE|ACK
		KSR.dialog.dlg_manage()
		return
	end

	if KSR.is_method("INVITE") and KSR.siputils.has_totag() < 0 and (not (KSR.isflagset(FLT_ACALLS))) then
		local active_calls = KSR.pv.getvn("$xavp(caller[0]=>active_calls)", 0)
		if active_calls > 0 then
			local rc =  KSR.dialog.get_profile_size("caller", KSR.pv.get("$fU") .. "@" .. KSR.pv.get("$fd"), "$var(acsize)")
			if rc < 0 then
				KSR.sl.sl_send_reply(500, "No more active calls")
				KSR.x.exit()
			end
			local acsize = KSR.pv.getvn("$var(acsize)", 0)
			KSR.info(KSR.pv.get("$fU") .. "@" .. KSR.pv.get("$fd") .. " acsize = " .. acsize .. "\n")
			if acsize >= active_calls then
				KSR.sl.sl_send_reply(503, "No more active calls")
				KSR.x.exit()
			end

			KSR.dialog.set_dlg_profile("caller", KSR.pv.get("$fU") .. "@" .. KSR.pv.get("$fd"))
		end

		KSR.setflag(FLT_ACALLS)
		KSR.dialog.dlg_manage()
	end
end
