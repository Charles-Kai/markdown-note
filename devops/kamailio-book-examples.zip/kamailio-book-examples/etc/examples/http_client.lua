-- apk add lua lua-cjson

local cjson = require 'cjson'

function ksr_request_route()
	ksr_register_always_ok()

	local rm = KSR.pv.gete("$rm")
	local fu = KSR.pv.gete("$fu")
	local ru = KSR.pv.gete("$ru")
	local si = KSR.pv.gete("$si")
	KSR.info("request: si: " .. si .. " rm: " .. rm .. " from " .. fu .. " to " .. ru .. "\n")

	local url = "http://" .. KSR.kx.get_def("KAM_IP_LOCAL") .. ":" .. KSR.kx.get_def("KAM_SIP_PORT")
	local req = {
		rm = rm,
		fu = fu,
		ru = ru,
		si = si,
	}
	local post_body = cjson.encode(req)
	local code = KSR.http_client.query_post_hdrs(url, post_body, "Content-Type: application/json\r\nAuthorization: Bearer 1234", "$var(result)")

	KSR.info("code: " .. code .. "\n")
	KSR.info("result: " .. KSR.pvx.var_get("result") .. "\n")

	if code == 200 then
		result = cjson.decode(KSR.pvx.var_get("result"))
		KSR.forward_uri(result.route)
	else
		KSR.sl.sl_send_reply(500, "Internal Error")
	end
end

function ksr_xhttp_event(evname)
	KSR.info("==== http request:" ..  evname .. " " .. "Ri:" ..  KSR.pv.get("$Ri") .. "\n")

	if KSR.hdr.get("Authorization") ~= "Bearer 1234" then
		KSR.hdr.append_to_reply('WWW-Authenticate: Bearer error="invalid_token"\r\n')
		KSR.xhttp.xhttp_reply("401", "Unauthorized", "", '{"code": 401, "message": "invalid_token"}')
		return
	end

	local content_type = KSR.pv.get("$cT") or ""
	local req_body = KSR.pv.get("$rb")

	if not req_body or content_type ~= "application/json" then
		KSR.xhttp.xhttp_reply(400, "Client Error", "text/plain", "invalid content_type or body")
		return
	end

	-- local jbody = cjson.decode(req_body)
	KSR.notice("request body: " .. req_body .. "\n")

	local reply = {
		route = FS1_URI
	}
	local body = cjson.encode(reply)
	KSR.xhttp.xhttp_reply(200, "OK", "application/json", body)
	return 1
end
