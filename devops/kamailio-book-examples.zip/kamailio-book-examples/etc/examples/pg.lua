function xdb_get_row(xavp, irow)
	return KSR.pv.get("$xavp(" .. xavp .. "[" .. tostring(irow) .. "])")
end

function xdb_gete_col(xavp, irow, col_name)
	return KSR.pv.gete("$xavp(" .. xavp .. "[" .. tostring(irow) .. "]=>" .. col_name ..")")
end

function ksr_request_route()
	ksr_register_always_ok()

	local sql = "SELECT * FROM version"

	local ok = KSR.sqlops.sql_query("example", sql, "version");
	local nrows = tonumber(KSR.pv.get("$dbr(version=>rows)"))
	local ncols = tonumber(KSR.pv.get("$dbr(version=>cols)"))
	KSR.info("number of rows in table: " .. nrows .. "\n");
	local i = 0
	local j = 0
	while j < ncols do
		KSR.info("col#" .. j .. ": " .. KSR.pv.gete("$dbr(version=>colname[" .. j .. "])") .. "\n")
		j = j + 1
	end
	while i < nrows do
		j = 0
		while j < ncols do
			KSR.info("#" .. i .. "-" .. j .. ":" .. KSR.pv.get("$dbr(version=>[" .. i .. "," .. j .. "])") .. "\n")
			j = j + 1
		end
		i = i + 1
	end

	KSR.sqlops.sql_result_free("version")

	ok = KSR.sqlops.sql_xquery("example", sql, "version")
	if ok >= 0 then
		KSR.info('xquery sql ok\n')
		KSR.sqlops.sql_result_free("version")
		i = 0
		while xdb_get_row("version", i) do
			KSR.info("id=" .. xdb_gete_col("version", i, "id") ..
			" table_name=" .. xdb_gete_col("version", i, "table_name") ..
			" table_version=" .. xdb_gete_col("version", i, "table_version") ..
			"\n")
			i = i + 1
		end
	else
		KSR.error("SELECT ERROR " .. ok .. "\n")
	end

	KSR.sl.sl_send_reply(404, "Not Found")
end
