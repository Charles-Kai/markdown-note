function ksr_request_route()
	ksr_register_always_ok()
	local ru = KSR.pv.get("$ru")
	KSR.info("$ru = " .. ru .. " before alias_db lookup\n")
	rc = KSR.alias_db.lookup("dbaliases")
	if rc == 1 then
		local new_ru = KSR.pv.get("$ru")
		KSR.info("$ru = " .. new_ru .. " after alias_db lookup\n")
		KSR.tm.t_relay()
		KSR.x.exit()
	else
		KSR.err("alias_db lookup failed\n")
		KSR.sl.sl_send_reply(404, "Not Found")
	end
end
