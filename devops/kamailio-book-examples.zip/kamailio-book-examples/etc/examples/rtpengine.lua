function ksr_request_route()
	ksr_register_always_ok()

	if KSR.is_INVITE() then
		KSR.rtpengine.rtpengine_offer("replace-origin replace-session-connection direction=pub direction=priv")
		KSR.tm.t_on_reply("ksr_onreply_manage");
	end

	if KSR.is_BYE() then
		KSR.rtpengine.rtpengine_delete("")
	end

	KSR.rr.record_route();
	KSR.pv.sets("$du", FS1_URI)
	KSR.tm.t_relay()
end

function ksr_onreply_manage()
	KSR.dbg("incoming reply\n");
	local scode = KSR.kx.get_status();
	if scode>100 and scode<299 then
		KSR.rtpengine.rtpengine_answer("replace-origin replace-session-connection direction=priv direction=pub")
	end
	return 1;
end
