-- connect to kamailio evapi module
-- feed kamailio route, message format in JSON-RPC

-- kamailio.cfg:
--	loadmodule "evapi.so"
--	modparam("evapi", "bind_addr", "127.0.0.1:8888")
--	modparam("evapi", "netstring_format", 1)

-- debian:
-- 	apt install lua-socket lua-cjson

-- alpine:
-- 	apk add lua-socket lua-cjson

-- about kamailio evapi
-- 	https://kamailio.org/docs/modules/devel/modules/evapi.html

-- about netsting
--	https://en.wikipedia.org/wiki/Netstring

json = require("cjson")
socket = require("socket")
tcp = assert(socket.tcp())

host, port = "127.0.0.1", 8888

FS1_IP = 'kb-fs1'
FS1_PORT = '5080'
FS1_IP_PORT = FS1_IP .. ':' .. FS1_PORT
FS1_URI = 'sip:' .. FS1_IP_PORT
FS1_UDP = 'udp:' .. FS1_IP_PORT

function write_netstring_data(str)
	print("--- write_netstring_data:\n" .. str)
	local len = #str
	tcp:send(tostring(len) .. ":" .. str .. ",")
end

function read_nbyes(n)
	local s, status = tcp:receive(n)
	return s, status
end

evapi_data = ""
evapi_state = 1

function read_netstring_data()
	local len = 0
	while true do
		local c, status = read_nbyes(1)
		if status == "closed" then
			return c, status
		end

		if evapi_state == 1 then
			if c == ':'  then
				evapi_state = 2
				len = tonumber(evapi_data)
				evapi_data = ""
			else
				evapi_data = evapi_data .. c
			end
		end

		if evapi_state == 2 then
			evapi_data, status = read_nbyes(len)
			if status == "closed" then
				return evapi_data, status
			else
				evapi_state = 3
			end
		end

		if evapi_state == 3 then
			local return_data = evapi_data
			evapi_data = ""
			evapi_state = 1
			read_nbyes(1) -- skip ','
			return return_data
		end
	end
end

print("connecting to " .. host .. ":" .. port)
tcp:connect(host, port)
print("connected")
write_netstring_data('{ "jsonrpc": "2.0", "id": "0", "method": "login", "params": { "username": "evapi", "password": "secret"} }')
--tcp:setoption("tcp-nodelay", true)
--tcp:settimeout(1, "t")

while true do
    local data, status = read_netstring_data()
	if status == "closed" then break end
	print("--- read_netstring_data:\n" .. data)

	local req = json.decode(data)
	if req and req.id and req.method == 'route' and req.params then
		local dest = req.params.dest
		print("received a call to " .. dest .. "\n")
		local response = {}
		response.id = req.id
		response.jsonrpc = "2.0"
		local result = {}
		response.result = result
		result.route = FS1_URI
		write_netstring_data(json.encode(response))
	end
end
