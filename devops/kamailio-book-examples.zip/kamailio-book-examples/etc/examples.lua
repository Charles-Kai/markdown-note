FS1_IP = 'kb-fs1'
FS1_PORT = '5080'
FS1_IP_PORT = FS1_IP .. ':' .. FS1_PORT
FS1_URI = 'sip:' .. FS1_IP_PORT
FS1_UDP = 'udp:' .. FS1_IP_PORT

function k_dofile(file)
	local BASE="/etc/kamailio/examples/"
	dofile(BASE .. file)
end

function ksr_register_always_ok()
	if KSR.is_method_in("R") then
		KSR.sl.sl_send_reply(200, "OK");
		KSR.x.exit()
	end
end

-- 读入其他文件

-- chapter6 ----------------------------
k_dofile("simple-log.lua")
-- k_dofile("simple-secure.lua")
-- k_dofile("stateless-forward.lua")
-- k_dofile("stateless-forward2.lua")
-- k_dofile("stateful-relay.lua")
-- k_dofile("forking-parallel.lua")
-- k_dofile("forking-serial.lua")
-- k_dofile("dispatcher.lua")
-- k_dofile("pg.lua")
-- k_dofile("http_client.lua")
-- k_dofile("http_async_client.lua")
-- k_dofile("rtjson.lua")
-- k_dofile("mtree.lua")
-- k_dofile("websocket.lua")
-- k_dofile("sipdump.lua")
-- k_dofile("evapi-event.lua")
-- k_dofile("native.lua")
-- k_dofile("evapi.lua")
-- k_dofile("dialplan.lua")
-- k_dofile("lcr.lua")

-- chapter8 ----------------------------
-- k_dofile("prefix-route.lua")
-- k_dofile("drouting.lua")
-- k_dofile("speed-dial.lua")
-- k_dofile("alias-db.lua")
-- k_dofile("location.lua")
-- k_dofile("uac.lua")
-- k_dofile("xavp.lua")
-- k_dofile("acc.lua")
-- k_dofile("path.lua")
-- k_dofile("rtpengine.lua")

-- chapter9 ----------------------------
-- k_dofile("pblock.lua")
-- k_dofile("pipelimit.lua")
-- k_dofile("userban.lua")
-- k_dofile("active-calls.lua")

-- k_dofile("voip-perf.lua")
