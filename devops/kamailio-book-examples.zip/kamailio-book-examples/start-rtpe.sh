#!/bin/sh
prep_term()
{
    unset term_child_pid
    unset term_kill_needed
    trap 'handle_term' TERM INT
}

handle_term()
{
    if [ "${term_child_pid}" ]; then
        kill -TERM "${term_child_pid}" 2>/dev/null
    else
        term_kill_needed="yes"
    fi
}

wait_term()
{
    term_child_pid=$!
    if [ "${term_kill_needed}" ]; then
        kill -TERM "${term_child_pid}" 2>/dev/null
    fi
    wait ${term_child_pid}
    trap - TERM INT
    wait ${term_child_pid}
}

# KAM_IP_PUBLIC=`dig +short myip.opendns.com @resolver1.opendns.com`

prep_term
# echo 65535 > /writeable-proc/sys/net/core/somaxconn
RTPE_IP_LOCAL=$(ip route get 8.8.8.8 | awk 'NR==1 {print $7}') 
RTPE_IP_PUBLIC=$KAM_IP_PUBLIC \

rtpengine --interface $RTPE_IP_LOCAL\!$RTPE_IP_PUBLIC --listen-ng $RTPE_IP_LOCAL:2223 --dtls-passive -f -m $RTPE_RTP_START -M $RTPE_RTP_END  -E -L 7 --log-facility=local1

wait_term
