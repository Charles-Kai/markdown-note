# 《Kamailio实战》随书代码

本目录是《Kamailio实战》随书附赠代码。使用Makefile维护以方便在macOS和Linux上运行。Windows用户也可以参考Makefile中的相关命令执行。

我们默认使用Docker环境，如何运行Docker请参阅本书附录D以及 https://github.com/rts-cn/xswitch-free 上的相关链接。

下面的命令在书中相关的章节都有相应的说明，下面是简单的操作步骤，仅供参考。

初始化。主要是产生`docker/.env`配置文件等。

```sh
make setup
```

修改`docker/.env`，以便适合你自己的环境。建议阅读`docker`目录下相关的`.yml`文件以便更深入了解。

每次重启宿主机后，首次使用时，先初始化一个网络：

```sh
make network
```

启动Kamilio容器：

```sh
make up
```

停止：

```sh
make down
```

进入Kamailio容器：

```sh
make sh
```

Kamailio容器启动后，将不会自动启动`kamailio`进程，这主要是为了测试和调试方便。进入Kamailio容器后，可以使用如下命令手动启动Kamailio：

```sh
/start-kam.sh
```

本仓库`etc/`目录的文件将会挂载到Kamailio容器中。可以直接在宿主机上修改文件然后在容器内重启`kamailio`或执行`kamcmd app_lua.reload`等重读相关的路由脚本。

启动FreeSWITCH容器：

```sh
make up-fs1
```

进入FreeSWITCH容器：

```sh
make sh-fs1
```

启动PostgreSQL数据库容器：

```sh
make up-pg
```

初始化PostgreSQL数据库：

```sh
make create-kam-pg
```

如果任何地方出错，可以使用如下命令重来：

```sh
make down-pg
rm -rf cache/pgdata
make up-pg
```

如果使用MySQL数据库，可以用如果命令创建数据库：

```sh
make create-kam-mysql
```

所有的容器均以`kb-`开头。查看

```sh
docker ps
docker stats
```

`db.yml`中提供了MySQL和MariaDB，两者可能稍有差异，如果连不上MySQL，需要进入`kb-mysql`容器对客户端对进授权，授权前需要先获取客户端的IP地址，下面以`172.22.0.3`为例：

```
make bash-mysql
mysql
GRANT ALL PRIVILEGES ON database.* TO 'root'@'172.22.0.3';
```

---

技术日新月异，Kamailio也是在不断发展变化的。请参考本书在线站点 <http://book.dujinfang.com> 获取内容更新。
